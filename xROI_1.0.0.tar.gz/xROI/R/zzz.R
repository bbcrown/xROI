globalVariables(names = c('Year','Month', 'Day', 'Hour', 'Minute', 'Second',
                          'HHMMSS','DOY', 'Date', 'DateTime', 'YearDOY',
                          'ID', 'Label', 'x', 'y', 'z', '.', 'archive',
                          'mainDataPath', 'middayListPath', 'newpath', 'path', 'filenames',
                          'band', 'blackness',  'conT', 'dukehw', 'empty',
                          'b5', 'b10', 'b25', 'b75', 'b90', 'b95', 'blue',
                          'g5', 'g10', 'g25', 'g75', 'g90', 'g95', 'green',
                          'r5', 'r10', 'r25', 'r75', 'r90', 'r95', 'red'))
