globalVariables(names = c('Year','Month', 'Day', 'HHMMSS', 'x', 'y','.',
'DOY', 'Date', 'DateTime', 'Hour', 'ID', 'Label', 'Minute', 'Second', 'V1', 'YearDOY', 'archive', 'b2.5',
'b25', 'b75', 'b975', 'band', 'blackness', 'blue', 'conT', 'dukehw', 'empty', 'filenames', 'g', 'g2.5',
'g25', 'g75', 'g975', 'green', 'mainDataPath', 'middayListPath', 'newpath', 'path', 'r2.5', 'r25',
'r75', 'r975', 'red'))
