#' An example set of RGB images
#'
#' This is infact a binary pacakge of zipped folder. The zipped folder contain images and their metadata.
#'  The dataset is used only internally by the app
#'
#' @format An image dataset as an example to use the app:
#' \describe{
#'   \item{.jpg files}{RGB images}
#'   \item{files.csv}{List of all images to be loaded and their assocated timing}
#'   ...
#' }
"dukehw"
